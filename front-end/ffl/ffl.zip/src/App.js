import './App.css';
import Table from './components/table.js';
import { BrowserRouter } from 'react-router-dom';
function App() {
  return (
    <BrowserRouter>
    <h1>THE LEAGUE 2024 DRAFT</h1>
          <Table/>
    
    </BrowserRouter>
  );
}

export default App;
